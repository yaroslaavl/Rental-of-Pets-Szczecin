create function limitkredytowy(wartosc double precision) returns character varying
    language sql
RETURN (SELECT CASE WHEN (wartosc < (100000)::double precision) THEN 'mały'::text WHEN ((wartosc >= (100000)::double precision) AND (wartosc < (200000)::double precision)) THEN 'średni'::text ELSE 'duży'::text END AS "case");

alter function limitkredytowy(double precision) owner to postgres;

