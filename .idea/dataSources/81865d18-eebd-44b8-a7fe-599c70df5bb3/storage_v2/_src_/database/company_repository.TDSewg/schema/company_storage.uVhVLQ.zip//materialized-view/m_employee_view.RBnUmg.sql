create materialized view m_employee_view as
SELECT company.name,
       e.last_name,
       e.salary,
       count(*) OVER ()                                                            AS count,
       max(e.salary) OVER (PARTITION BY company.name)                              AS max,
       lag(e.salary) OVER (ORDER BY e.salary)                                      AS lag,
       row_number() OVER ()                                                        AS row_number,
       dense_rank() OVER (PARTITION BY company.name ORDER BY e.salary NULLS FIRST) AS dense_rank
FROM company_storage.company
         LEFT JOIN company_storage.employee e ON company.id = e.company_id
ORDER BY company.name;

alter materialized view m_employee_view owner to postgres;

