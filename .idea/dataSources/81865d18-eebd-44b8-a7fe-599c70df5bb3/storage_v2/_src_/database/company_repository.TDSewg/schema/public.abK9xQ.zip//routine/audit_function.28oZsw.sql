create function audit_function() returns trigger
    language plpgsql
as
$$
begin
    insert into audit(id,table_name,date)
    values (id,tg_table_name,now());
    return null;
end;
$$;

alter function audit_function() owner to postgres;

